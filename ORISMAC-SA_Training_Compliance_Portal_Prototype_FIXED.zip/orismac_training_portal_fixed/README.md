# ORISMAC-SA Employee Training & Authorisation Portal — Working Prototype

This is a browser-based multi-client prototype based on the supplied ORISMAC-SA Excel tracker.

## Demo logins
- **ORISMAC-SA Admin:** `admin@orismacsa.co.za` / `Admin123!`
- **Client:** `demo@client.co.za` / `Client123!`

## Included
- Secure-looking login and role-based navigation (prototype only)
- ORISMAC-SA administrator dashboard
- Client-specific data filtering
- Employee register
- 22 authorisations from the supplied tracker
- Training records with automatic status calculation
- Expiry report with priority levels
- Booking & Renewal Log
- Certificate upload/view in the browser prototype
- CSV report downloads
- Client management and client-login creation
- Excel employee-register import
- Local browser persistence using localStorage

## Important prototype limitation
This version is a **front-end prototype**, not a production security system. User credentials, records and uploaded certificates are stored in the browser's localStorage. Do not use it for real employee personal information or certificates until it is connected to a secure backend/database, authentication service and protected document storage.

## Run
Open `index.html` in a modern browser. The Excel import uses the SheetJS CDN, so an internet connection is needed for that feature.

## Recommended production architecture
- Web frontend: React/Next.js
- Authentication: Supabase Auth, Firebase Auth, or Auth0
- Database: PostgreSQL/Supabase
- Documents: private object storage with signed URLs
- Multi-tenancy: client_id row-level security
- Server-side audit log
- Automated email/WhatsApp renewal notifications
- PDF/Excel report generation
- Backups and POPIA-aligned access controls
